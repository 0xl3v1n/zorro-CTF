chmod 777 ./labs/uploads
chmod 777 .

